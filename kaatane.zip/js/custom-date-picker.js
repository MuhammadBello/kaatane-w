(function($) {
	
	"use strict";

	// Cache Selectors
	var date		=$('.dpd');
	
	
	//Date Picker//
	date.datepicker({
		format: 'mm-dd-yyyy'
	});
			
})(jQuery);